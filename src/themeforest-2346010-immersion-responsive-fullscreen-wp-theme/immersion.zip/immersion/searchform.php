<form method="get" id="searchform" action="<?php echo home_url(); ?>">

	<input type="text" placeholder="<?php _e('Search', THEME_SLUG);?>" name="s" />	
	<button type="submit" class="button"><?php _e('Search', THEME_SLUG);?></button>

</form>