<?php

$options[] = array(
		"name" => "Custom sidebars",
		"type" => "heading"
	);
    

$options[] = array(
			"name" => "Add Sidebar",
			"desc" => "enter the name of the sidebar you'd like to create then click the 'Create Sidebar' button",
			"id" => THEME_SLUG."custom_sidebars",
			"type" => "custom_sidebar"
		);



?>