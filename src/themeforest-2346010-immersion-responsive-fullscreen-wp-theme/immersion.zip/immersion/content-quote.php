<blockquote>

	<?php echo get_meta_option('quotes_text'); ?>

	<span></span>

</blockquote>
